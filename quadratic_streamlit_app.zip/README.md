# Quadratic Function Plotter

A Streamlit web app to plot the graph of a quadratic function:  
\[
y = ax^2 + bx + c
\]

## Features
- Interactive sliders for a, b, c
- Real-time plot updates
- LaTeX-rendered equation display

## Run locally
```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Deployed App
👉 [Click here to try it!](https://your-username-quadratic-streamlit.streamlit.app)
